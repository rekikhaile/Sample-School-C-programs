
void sort(int *start, int size);
int count_vowels(char *str);
void remove_comments(char *out, const char *in);
